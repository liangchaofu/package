udp2raw-tunnel for OpenWRT/LEDE

 适配 OpenWRT/LEDE 的 [udp2raw-tunnel][1] 编译文件
 
 更多内容，请看[wiki](https://github.com/sensec/openwrt-udp2raw/wiki)


  [1]: https://github.com/wangyu-/udp2raw-tunnel
  [2]: https://github.com/sensec/luci-app-udp2raw
